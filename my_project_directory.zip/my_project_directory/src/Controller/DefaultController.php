<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Core\Security;

class DefaultController extends AbstractController
{
    #[Route('/', name: 'app_default')]
    public function index(): Response
    {
        return $this->render('default/index.html.twig', [
            'controller_name' => 'DefaultController',
        ]);
    }

    #[Route('/login', name: 'login')]
    public function login(): Response
    {
        return new Response('login');
    }

    #[Route('/register', name: 'register')]
    public function register(): Response
    {
        return new Response('register');
    }

    #[Route('/logout', name: 'logout')]
    public function logout(): Response
    {
        throw new \Exception('Do\'t forget to activate logout in security.yaml');
    }

    #[Route('/redirect', name:'redirect')]
    public function redirectAction(Security $security)
    {
        if($security->isGranted('ROLE_ADMIN')) {
            return $this->redirectToRoute('app_admin');
        }
        if($security->isGranted('ROLE_KLANT')) {
            return $this->redirectToRoute('app_klant');
        }
        return $this->redirectToRoute('app_default');
    }
}
